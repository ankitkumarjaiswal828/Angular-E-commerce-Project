import { Component } from '@angular/core';
import { ServicesService } from '../Service/services.service';


@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrl: './employee-details.component.css'
})
export class EmployeeDetailsComponent {
  emplist: any = [];

  constructor(private emp: ServicesService) {
    emp.getEmployeesData().subscribe(((response: any) => {
      this.emplist = response;
    }))
  }
}
