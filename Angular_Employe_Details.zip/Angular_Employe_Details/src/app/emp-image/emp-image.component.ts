import { Component } from '@angular/core';

@Component({
  selector: 'app-emp-image',
  templateUrl: './emp-image.component.html',
  styleUrl: './emp-image.component.css'
})
export class EmpImageComponent {
  emp_img:string='assets/pic.jpeg'
}
