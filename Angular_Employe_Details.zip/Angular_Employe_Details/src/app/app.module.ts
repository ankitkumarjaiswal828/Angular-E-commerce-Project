import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AnkitComponent } from './ankit/ankit.component';
import { EMPIdComponent } from './emp-id/emp-id.component';
import { EmpSalaryComponent } from './emp-salary/emp-salary.component';
import { EmpImageComponent } from './emp-image/emp-image.component';

@NgModule({
  declarations: [
    AppComponent,
    AnkitComponent,
    EMPIdComponent,
    EmpSalaryComponent,
    EmpImageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
