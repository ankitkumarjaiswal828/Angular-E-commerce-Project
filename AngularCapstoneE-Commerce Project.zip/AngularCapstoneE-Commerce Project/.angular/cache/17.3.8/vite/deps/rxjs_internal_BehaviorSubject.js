import {
  BehaviorSubject
} from "./chunk-UYGZEGTL.js";
export {
  BehaviorSubject
};
//# sourceMappingURL=rxjs_internal_BehaviorSubject.js.map
