import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorServiceService {

  constructor() { }
  
  add(num1: number, num2: number): number{
    return num1 + num2;
  }

  subtract(num1: number, num2: number): number{
    return num1 - num2;
  }

  multyply(num1: number, num2: number): number{
    return num1 * num2;
  }
  
  divide(num1: number, num2: number): number|string {
    if (num2 === 0) {
      return "Error :- Not divided by Zero";
    }
    return num1 / num2;
  }
}
