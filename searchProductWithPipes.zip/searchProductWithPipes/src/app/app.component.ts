import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'searchProductWithPipes';
}

export interface Product{
  product_id: number;
  product_name: string;
  product_price: number;
  product_img: string;
  product_Description: string;
}