import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appHoverEffect]'
})
export class HoverEffectDirective {

  @HostBinding('style.backgroundColor') backgroundColor: string;

  constructor() {
    this.backgroundColor = 'transparent'; // Default background color
  }

  @HostListener('mouseenter') onMouseEnter() {
    this.backgroundColor = 'lightblue'; // Change background color on mouseover
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.backgroundColor = 'transparent'; // Reset background color on mouseleave
  }
}
