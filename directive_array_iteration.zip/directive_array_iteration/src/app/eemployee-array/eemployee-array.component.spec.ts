import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EemployeeArrayComponent } from './eemployee-array.component';

describe('EemployeeArrayComponent', () => {
  let component: EemployeeArrayComponent;
  let fixture: ComponentFixture<EemployeeArrayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EemployeeArrayComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EemployeeArrayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
