import { Component } from '@angular/core';

@Component({
  selector: 'app-emp-id',
  templateUrl: './emp-id.component.html',
  styleUrl: './emp-id.component.css'
})
export class EMPIdComponent {
   id: number = 502;
}
