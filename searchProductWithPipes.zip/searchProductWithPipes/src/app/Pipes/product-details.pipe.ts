import { Pipe, PipeTransform } from '@angular/core';
import { Product } from '../app.component';

@Pipe({
  name: 'productDetails'
})
export class ProductDetailsPipe implements PipeTransform {

  transform(products: Product[], searchitem:string): Product[] {
    if (!products || !searchitem) {
      return products
    }

    return products.filter((item) => 
      item.product_name.toLowerCase().includes(searchitem.toLowerCase()) || item.product_name.toUpperCase().includes(searchitem.toUpperCase())
    )
  }

}
