import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpImageComponent } from './emp-image.component';

describe('EmpImageComponent', () => {
  let component: EmpImageComponent;
  let fixture: ComponentFixture<EmpImageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmpImageComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmpImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
