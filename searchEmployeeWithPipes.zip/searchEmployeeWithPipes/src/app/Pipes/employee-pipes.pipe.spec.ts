import { EmployeePipesPipe } from './employee-pipes.pipe';

describe('EmployeePipesPipe', () => {
  it('create an instance', () => {
    const pipe = new EmployeePipesPipe();
    expect(pipe).toBeTruthy();
  });
});
