import { MyColorComponent } from './../my-color/my-color.component';
import { Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appMyColor]'
})
export class MyColorDirective {

  constructor(private eleref: ElementRef, private render: Renderer2) {
    // eleref.nativeElement.style.color = "green";
    // eleref.nativeElement.style.backgroundColor = "lightgreen"
    render.addClass(eleref.nativeElement,"classone")
   }

}
