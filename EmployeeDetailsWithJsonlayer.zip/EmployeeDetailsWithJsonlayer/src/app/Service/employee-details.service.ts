import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {
  private url: string = "assets/EmployeeDetails.json"

  constructor(private httpClient: HttpClient) { }
  
  getEmployeesData() {
    return this.httpClient.get(this.url)
  }
  
}
