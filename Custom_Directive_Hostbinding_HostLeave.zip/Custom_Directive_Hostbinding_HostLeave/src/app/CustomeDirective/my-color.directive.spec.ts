import { MyColorDirective } from './my-color.directive';

describe('MyColorDirective', () => {
  it('should create an instance', () => {
    const directive = new MyColorDirective();
    expect(directive).toBeTruthy();
  });
});
