import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HoverEffectDirective } from '../app/Directive/hover-effect.directive';
import { MyColorComponent } from './my-color/my-color.component';
import { MyColorDirective } from './CustomeDirective/my-color.directive';

@NgModule({

  declarations: [
    AppComponent,
    HoverEffectDirective,
    MyColorComponent,
    MyColorDirective
  ],
  
  imports: [
    BrowserModule,
    AppRoutingModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

