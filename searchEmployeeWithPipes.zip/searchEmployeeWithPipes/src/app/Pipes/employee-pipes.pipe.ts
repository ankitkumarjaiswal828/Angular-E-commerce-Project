import { Pipe, PipeTransform } from '@angular/core';
import { Employee } from '../app.component';

@Pipe({
  name: 'employeePipes'
})
  
export class EmployeePipesPipe implements PipeTransform {

  transform(employees: Employee[], searchText: string): Employee[] {
    
    if (!employees || !searchText) {
      return employees;
    }

    searchText = searchText.toLowerCase();

    return employees.filter(employees => employees.emp_name.toLowerCase().includes(searchText.toLowerCase()) ||
      employees.emp_name.toUpperCase().includes(searchText.toUpperCase()))
  }
}
