import { Component } from '@angular/core';
import { ServicesService } from '../Service/services.service';
@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent {
  product_list: any = [];
  constructor(private productDetails: ServicesService) {
    productDetails.getProductDetails().subscribe((response => {
      this.product_list = response;
    }))
  }
}
