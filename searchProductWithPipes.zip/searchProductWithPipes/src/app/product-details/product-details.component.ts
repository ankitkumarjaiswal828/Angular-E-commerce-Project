import { Product } from './../app.component';
import { Component } from '@angular/core';


@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent {

  searchitem:string = '';

 products:Product[]=[
    {
      "product_id": 1,
      "product_name": "Smart Watch",
      "product_price": 2000,
      "product_img": "../assets/1.webp",
      "product_Description": "Bluetooth Calling Smartwatch - Make & Receive calls on the go through the watch 1.83 HD Display with 2.5D Curved Glass | 240*286 Pixel High Resolution",
    },
    {
      "product_id": 2,
      "product_name": "Wireless Headphone",
      "product_price": 4000,
      "product_img": "assets/2.webp",
      "product_Description": "With Mic:Yes Automatically on, automatically connected Easy setup for all your Apple devices Quick access to Siri by saying Hey Siri Double-tap to play or skip forward",
    },
    {
      "product_id": 3,
      "product_name": "Wireless KeyBoard",
      "product_price": 6000,
      "product_img": "assets/3.webp",
      "product_Description": "Size: Handheld Interface: Bluetooth Bluetooth 5.3 & 2.4 GHz Receiver: Switch between devices effortlessly Effortless Multitasking: Simultaneous pairing with up to three devices Convenient Smartphone Holder Enhanced Functionality with Multimedia Hotkeys",
    },
    {
      "product_id": 4,
      "product_name": "Realme p1 SmartPhone",
      "product_price": 30000,
      "product_img": "assets/4.webp",
      "product_Description": "68 GB ROM 13.49 cm (5.1 inch) Super Retina XDR Display 48MP + 12MP | 12MP Front Camera A16 Bionic Chip, 4 Core Processor Processor",
    },
    {
      "product_id": 5,
      "product_name": "IPhone 15",
      "product_price": 1200000,
      "product_img": "assets/5.webp",
      "product_Description": "128 GB ROM 15.49 cm (6.1 inch) Super Retina XDR Display 48MP + 12MP | 12MP Front Camera A16 Bionic Chip, 6 Core Processor Processor",
    },
    {
      "product_id": 6,
      "product_name": "Realme p1 SmartPhone",
      "product_price": 30000,
      "product_img": "assets/4.webp",
      "product_Description": "68 GB ROM 13.49 cm (5.1 inch) Super Retina XDR Display 48MP + 12MP | 12MP Front Camera A16 Bionic Chip, 4 Core Processor Processor",
    }
  ]

}
