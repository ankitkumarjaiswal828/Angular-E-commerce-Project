import { Component } from '@angular/core';
import {Employee} from '../app.component'
@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrl: './employee-details.component.css'
})


export class EmployeeDetailsComponent {

  searchText: string = '';

  employees:Employee[]=[
    {
      "emp_id": 1,
      "emp_name": "Ankit",
      "emp_salary": 20000,
      "emp_desination": "Software Engineer",
      "emp_img": "assets/1.jpeg"
    },
    {
      "emp_id": 2,
      "emp_name": "Ruchi",
      "emp_salary": 40000,
      "emp_desination": "SAP Developer",
      "emp_img": "assets/2.jpeg"
    },
    {
      "emp_id": 3,
      "emp_name": "Sachine",
      "emp_salary": 60000,
      "emp_desination": "Chemical Engineer",
      "emp_img": "assets/3.jpeg"
    },
    {
      "emp_id": 4,
      "emp_name": "Bambam",
      "emp_salary": 80000,
      "emp_desination": "Network Engineer",
      "emp_img": "assets/4.jpeg"
    },
    {
      "emp_id": 5,
      "emp_name": "Jagveer",
      "emp_salary": 120000,
      "emp_desination": "Civil Engineer",
      "emp_img": "assets/5.jpeg"
    }
  ]


}
