import { Component } from '@angular/core';
import {CalculatorServiceService} from "../Service/calculator-service.service"
@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrl: './calculator.component.css'
})
export class CalculatorComponent {

  n1: number = 0;
  n2: number = 0;
  result: number | string = '';

  constructor(private calculatorSerice: CalculatorServiceService) {}

  setOperation(val: string) {

    switch (val) {

      case '+':
        this.result = this.calculatorSerice.add(this.n1 , this.n2) ;
        break;

      case '-':
        this.result = this.calculatorSerice.subtract(this.n1 , this.n2);
        break;

      case '*':
        this.result = this.calculatorSerice.multyply(this.n1 , this.n2);
        break;

      case '/':
        this.result = this.calculatorSerice.divide(this.n1 ,this.n2);
        break;

      default:
        this.result = 'Invalid operation';
    }
  }
}
