import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrayProductComponent } from './array-product.component';

describe('ArrayProductComponent', () => {
  let component: ArrayProductComponent;
  let fixture: ComponentFixture<ArrayProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ArrayProductComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ArrayProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
