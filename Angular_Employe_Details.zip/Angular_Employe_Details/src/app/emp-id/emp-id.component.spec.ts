import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EMPIdComponent } from './emp-id.component';

describe('EMPIdComponent', () => {
  let component: EMPIdComponent;
  let fixture: ComponentFixture<EMPIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EMPIdComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EMPIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
