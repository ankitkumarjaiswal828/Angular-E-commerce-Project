import { Component } from '@angular/core';

@Component({
  selector: 'app-ankit',
  templateUrl: './ankit.component.html',
  styleUrl: './ankit.component.css'
})
export class AnkitComponent {
    name:string='Ankit kumar'
}
