import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Custom_Directive_Hostbinding_HostLeave';
  clsone: boolean = true;
  clstwo: boolean = true;
  clr: string = "red";
  bgclr: string = 'pink';
}
