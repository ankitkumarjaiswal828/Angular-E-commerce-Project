import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductDetailsService {

  private url: string = "assets/productDetails.json";
  constructor(private httpClient: HttpClient) { }
  
  getProductDetails() {
    return this.httpClient.get(this.url)
  }
}
