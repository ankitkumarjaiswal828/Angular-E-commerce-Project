import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'searchEmployeeWithPipes';
}

export interface Employee {
  emp_id: number,
  emp_name: string,
  emp_salary: number,
  emp_desination: string,
  emp_img: string
}