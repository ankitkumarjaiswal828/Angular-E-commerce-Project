import { Component } from '@angular/core';
import {ProductDetailsService} from "../Service/product-details.service"

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent {

  product_list: any = [];
  constructor(private productDetails:ProductDetailsService ) {
    productDetails.getProductDetails().subscribe((response => {
      this.product_list = response;
    }))
  }
}
