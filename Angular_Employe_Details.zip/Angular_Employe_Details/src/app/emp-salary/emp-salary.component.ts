import { Component } from '@angular/core';

@Component({
  selector: 'app-emp-salary',
  templateUrl: './emp-salary.component.html',
  styleUrl: './emp-salary.component.css'
})
export class EmpSalaryComponent {
sal: number = 27000;  
}
