import { Component } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrl: './calculator.component.css'
})
export class CalculatorComponent {

  n1:number = 0;
  n2: number = 0;
  result: number | string = '';
  
  setOperation(val: string) {
    
    switch (val) {
      
      case '+':
        this.result = this.n1 + this.n2;
        break;
      
      case '-':
        this.result = this.n1 - this.n2;
        break;
      
      case '*':
        this.result = this.n1 * this.n2;
        break;
      
      case '/':
        if (this.n2 !== 0) {
          this.result = this.n1 / this.n2;
        }
        else {
          this.result = 'Error: Division by zero';
        }

        break;
      
      default:
        this.result='Invalid operation';
    }
  }

 
  
}
