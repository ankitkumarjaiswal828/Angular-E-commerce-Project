import { Component } from '@angular/core';

@Component({
  selector: 'app-array-product',
  templateUrl: './array-product.component.html',
  styleUrl: './array-product.component.css'
})
export class ArrayProductComponent {

  array = [
    {
      proId: 1, proName: 'Samsung Galaxy M15 5G', proPrice: 14000, proDesc:'Samsung Galaxy M15 5G (Celestial Blue,6GB RAM,128GB Storage)| 50MP Triple Cam| 6000mAh Battery| MediaTek Dimensity 6100+|4 Gen. OS Upgrade & 5 Year Security Update|Super AMOLED Display|Without Charger',proImg:'assets/a.webp'
    },
    {
      proId: 2, proName: 'POCO C55 (Cool Blue, 6GB RAM, 128GB Storage)', proPrice: 12000, proDesc: 'POCO C55 (Cool Blue, 6GB RAM, 128GB Storage)| 50MP Triple Cam| 6000mAh Battery| MediaTek Dimensity 6100+|4 Gen. OS Upgrade & 5 Year Security Update|Super AMOLED Display|Without Charger', proImg: 'assets/b.webp'
    },
    {
      proId: 3, proName: 'Xiaomi 125 cm (50 inches) X 4K Dolby Vision Series Smart Google TV L50M8-A2IN (Black', proPrice: 33000, proDesc: 'Full HD (1920 x 1080) Resolution | Refresh Rate : 60 Hertz | Viewing angle : 178 degrees Connectivity: Dual Band Wi-Fi | 2 HDMI ports to connect set top box, Blu-ray speakers, or gaming console | 2 USB ports to connect hard drives and other USB devices', proImg: 'assets/c.webp'
    },
    {
      proId: 4, proName: 'JBL Tune 770NC Wireless Headphone', proPrice: 1599, proDesc: 'JBL Tune 770NC Wireless Over Ear ANC Headphones with Mic, Upto 70 Hrs Playtime, Speedcharge, Google Fast Pair, Dual Pairing, BT 5.3 LE Audio, Customize on Headphones App (Black)', proImg: 'assets/d.webp'
    },
    {
      proId: 5, proName: 'JBL C100SI Wired In Ear Headphones', proPrice: 6448, proDesc: 'JBL C100SI Wired In Ear Headphones with Mic, JBL Pure Bass Sound, One Button Multi-function Remote, Angled Buds for Comfort fit (Black)', proImg: 'assets/e.webp'
    },
    {
      proId: 6, proName: 'JBL Tune 215BT,In Ear Headphones', proPrice: 1299, proDesc: 'JBL Tune 215BT, 16 Hrs Playtime with Quick Charge, in Ear Bluetooth Wireless Earphones with Mic, 12.5mm Premium Earbuds with Pure Bass, BT 5.0, Dual Pairing, Type C & Voice Assistant Support (Black)', proImg: 'assets/f.webp'
    }

  ]
}
