import { Component } from '@angular/core';

@Component({
  selector: 'app-eemployee-array',
  templateUrl: './eemployee-array.component.html',
  styleUrl: './eemployee-array.component.css'
})
export class EemployeeArrayComponent {
  
  array = [
    { EmpId: 501, EmpName: "Ankit Singh", EmpSal: 20000, EmpDesign: "WD" ,editing: false},
    { EmpId: 502, EmpName: "Ankit", EmpSal: 22000, EmpDesign: "Software Engineer " ,editing: false},
    { EmpId: 518, EmpName: "Ruchi", EmpSal: 24000, EmpDesign: "SAP Devloper" ,editing: false},
    { EmpId: 503, EmpName: "Bambam", EmpSal: 25000, EmpDesign: "NE" ,editing: false},
    { EmpId: 517, EmpName: "Rohit", EmpSal: 27000, EmpDesign: "PHP devloper",editing: false }
  ]

  editItem(item: any) {
    item.editing = true;
  }

  saveItem(item: any) {
    item.editing = false;
  }

  deleteItem(index: number) {
    this.array.splice(index, 1);
  }

}
