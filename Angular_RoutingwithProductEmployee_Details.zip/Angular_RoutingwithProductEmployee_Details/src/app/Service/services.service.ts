import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  private url: string = "assets/Emp/EmployeeDetails.json"
  private prourl: string = "assets/Product/productDetails.json";

  constructor(private httpClient: HttpClient) { }

  getEmployeesData() {
    return this.httpClient.get(this.url)
   
  }
  getProductDetails() {
    return this.httpClient.get(this.prourl)
  }
}
