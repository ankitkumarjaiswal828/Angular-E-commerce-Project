import { Component} from '@angular/core';
import { EmployeeDetailsService } from '../Service/employee-details.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrl: './employee-details.component.css'
})
export class EmployeeDetailsComponent  {
  
  emplist: any = [];
  
  constructor(private emp: EmployeeDetailsService) { 
    emp.getEmployeesData().subscribe((response => {
      this.emplist = response;
    }))
  }
}