import { Component } from '@angular/core';

@Component({
  selector: 'app-my-color',
  templateUrl: './my-color.component.html',
  styleUrl: './my-color.component.css'
})
export class MyColorComponent {

}
